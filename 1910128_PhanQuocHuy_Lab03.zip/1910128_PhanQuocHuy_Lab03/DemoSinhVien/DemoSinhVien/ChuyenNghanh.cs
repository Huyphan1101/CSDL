﻿namespace DemoSinhVien
{
    internal class ChuyenNghanh
    {
    }
}