﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoSinhVien
{
    public enum KieuTim
    {
        TheoMa,
            TheoHoTen,
            TheoNgaySinh
    }
}
