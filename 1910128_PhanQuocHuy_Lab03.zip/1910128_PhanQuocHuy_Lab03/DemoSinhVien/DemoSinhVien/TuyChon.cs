﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoSinhVien
{
    public partial class TuyChon : Form
    {
        public string Holder { get; private set; }

        public TuyChon()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn có chắc muốn thoát không ?", "Error", MessageBoxButtons.YesNoCancel);
            Application.Exit();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            var kieuTim = KieuTim.TheoHoTen;
            if (radioButton1.Checked)
            {
                kieuTim = KieuTim.TheoMa;
            }
            else if (radioButton2.Checked)
            {
                kieuTim = KieuTim.TheoHoTen;
            }
            else if (radioButton3.Checked)
            {
                kieuTim = KieuTim.TheoNgaySinh;
            }

            var ketQua = QuanLySinhVien.Tim(txtTuKhoa.Text, kieuTim);

            if (ketQua is null)
            {
                MessageBox.Show("Không tìm thấy thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Form1 frm = new Form1();
                frm.SetText(ketQua.ToString());
                frm.ShowDialog();
            }    
            txtTuKhoa.Text = Holder;
            txtTuKhoa.GotFocus += RemovePlaceHolderText;
            txtTuKhoa.LostFocus += ShowPlaceHolderText;

        }

        private void ShowPlaceHolderText(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTuKhoa.Text))
            {
                txtTuKhoa.Text = Holder;
            }

        }

        private void RemovePlaceHolderText(object sender, EventArgs e)
        {

            if (txtTuKhoa.Text == Holder)
            {
                txtTuKhoa.Text = "";
            }

        }
        public string HoTen { get; set; }

        public int Maso { get; set; }

        public int NgaySinh { get; set; }

        public TuyChon(string hoten, int maso, DateTime ns)
        {
            this.HoTen = hoten;
            this.Maso = maso;

        }

        public void GetInfo()
        {
            Console.WriteLine("Name: {0}, Maso: {1}", HoTen, Maso, NgaySinh);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Name: {0}, Age: {1}", HoTen, Maso, NgaySinh);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label1.Text = radioButton1.Text;
                txtTuKhoa.Text = "";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton2.Checked)
            {
                label1.Text = radioButton2.Text;
                txtTuKhoa.Text = "";
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton3.Checked)
            {
                label1.Text = radioButton3.Text;
                txtTuKhoa.Text = "";
            }
        }
    }
}
