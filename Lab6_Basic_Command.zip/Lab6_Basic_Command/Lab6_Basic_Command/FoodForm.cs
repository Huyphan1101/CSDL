﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6_Basic_Command
{
    public partial class FoodForm : Form
    {
        int categoryID;
        public FoodForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FoodForm_Load(object sender, EventArgs e)
        {

        }
        public void LoadFood(int categoryID)
        {

            // Tạo chuỗi kết nối tới cơ sở dữ liệu RestaurantManagement
            string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
            // Tạo đối tượng kết nối
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            // Tạo đối tượng thực thi lệnh
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = "select Name from Category where ID = " + categoryID;
            sqlConnection.Open();
            string catName = sqlCommand.ExecuteScalar().ToString();
            this.Text = "Danh sách các món ăn thuộc nhóm : " + catName;
            sqlCommand.CommandText = "select * from Food where FoodCategoryID =" + categoryID;
            // Tạo đối tượng DatAdapter
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            // Tạo DataTable để chứa dữ liệu
            DataTable dt = new DataTable("Food");
            da.Fill(dt);
            // Hiện thị danh sách món ăn lên form
            dgvFood.DataSource = dt;
            // Đóng kết nối và giải phóng bộ nhớ
            sqlConnection.Close();
            sqlConnection.Dispose();
            da.Dispose();

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string connectionString = @"Data Source=LAPTOP-IU2D0JB7\HUYSQLSERVER;Initial Catalog=RestaurantManagement;Integrated Security=True";
            // Tạo đối tượng kết nối
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            // Tạo đối tượng thực thi lệnh 
            SqlCommand cmd = sqlConnection.CreateCommand();

            // mở kết nối đến csdl
            sqlConnection.Open();

            for (int i = 0; i < dgvFood.Rows.Count - 1; i++)
            {
                int id = (int)dgvFood.Rows[i].Cells["ID"].Value;
                cmd.CommandText = "SELECT * FROM Food WHERE ID = " + id;
                var checkID = cmd.ExecuteScalar();

                if (checkID == null)
                {
                    string query = string.Format(" insert into Food(Name, Unit, FoodCategoryID, Price, Notes) " +
                    "values (N'{0}', N'{1}', {2}, {3}, N'{4}')",
                    dgvFood.Rows[i].Cells["Name"].Value,
                    dgvFood.Rows[i].Cells["Unit"].Value,
                    categoryID,
                    dgvFood.Rows[i].Cells["Price"].Value,
                    dgvFood.Rows[i].Cells["Notes"].Value.ToString());
                    cmd.CommandText = query;
                    MessageBox.Show("Thêm mới thành công");
                }
                else
                {
                    string query = string.Format(" update Food set Name = N'{0}', Unit = N'{1}', FoodCategoryID = {2}, Price = {3}, Notes = N'{4}' WHERE ID = {5}",
                    dgvFood.Rows[i].Cells["Name"].Value,
                    dgvFood.Rows[i].Cells["Unit"].Value,
                    categoryID,
                    dgvFood.Rows[i].Cells["Price"].Value,
                    dgvFood.Rows[i].Cells["Notes"].Value.ToString(),
                    id.ToString());
                    cmd.CommandText = query;
                    MessageBox.Show("Cập nhật thành công");
                }
            }

            sqlConnection.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvFood.SelectedRows.Count == 0) return;

            var selectedRow = dgvFood.SelectedRows[0];

            string foodID = selectedRow.Cells[0].Value.ToString();
            string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
            // Tạo đối tượng kết nối
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            // Tạo đối tượng thực thi lệnh
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            string query = "DELETE FROM Food WHERE ID = " + foodID;
            sqlCommand.CommandText = query;

            sqlConnection.Open();

            int numOfRowsEffected = sqlCommand.ExecuteNonQuery();

            if (numOfRowsEffected != 1)
            {
                MessageBox.Show("Có lỗi xảy ra.");
                return;
            }

            dgvFood.Rows.Remove(selectedRow);

            sqlConnection.Close();

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvFood.SelectedRows.Count == 0) return;

            var selectedRow = dgvFood.SelectedRows[0];

            string foodID = selectedRow.Cells[0].Value.ToString();
            string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
            // Tạo đối tượng kết nối
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            // Tạo đối tượng thực thi lệnh
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            string query = "DELETE FROM Food WHERE ID = " + foodID;
            sqlCommand.CommandText = query;

            sqlConnection.Open();

            int numOfRowsEffected = sqlCommand.ExecuteNonQuery();

            if (numOfRowsEffected != 1)
            {
                MessageBox.Show("Có lỗi xảy ra.");
                return;
            }

            dgvFood.Rows.Remove(selectedRow);

            sqlConnection.Close();

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {

            string connectionString = @"Data Source=LAPTOP-IU2D0JB7\HUYSQLSERVER;Initial Catalog=RestaurantManagement;Integrated Security=True";
            // Tạo đối tượng kết nối
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            // Tạo đối tượng thực thi lệnh 
            SqlCommand cmd = sqlConnection.CreateCommand();

            // mở kết nối đến csdl
            sqlConnection.Open();

            for (int i = 0; i < dgvFood.Rows.Count - 1; i++)
            {
                int id = (int)dgvFood.Rows[i].Cells["ID"].Value;
                cmd.CommandText = "SELECT * FROM Food WHERE ID = " + id;
                var checkID = cmd.ExecuteScalar();

                if (checkID == null)
                {
                    string query = string.Format(" insert into Food(Name, Unit, FoodCategoryID, Price, Notes) " +
                    "values (N'{0}', N'{1}', {2}, {3}, N'{4}')",
                    dgvFood.Rows[i].Cells["Name"].Value,
                    dgvFood.Rows[i].Cells["Unit"].Value,
                    categoryID,
                    dgvFood.Rows[i].Cells["Price"].Value,
                    dgvFood.Rows[i].Cells["Notes"].Value.ToString());
                    cmd.CommandText = query;
                    MessageBox.Show("Thêm mới thành công");
                }
                else
                {
                    string query = string.Format(" update Food set Name = N'{0}', Unit = N'{1}', FoodCategoryID = {2}, Price = {3}, Notes = N'{4}' WHERE ID = {5}",
                    dgvFood.Rows[i].Cells["Name"].Value,
                    dgvFood.Rows[i].Cells["Unit"].Value,
                    categoryID,
                    dgvFood.Rows[i].Cells["Price"].Value,
                    dgvFood.Rows[i].Cells["Notes"].Value.ToString(),
                    id.ToString());
                    cmd.CommandText = query;
                    MessageBox.Show("Cập nhật thành công");
                }
            }

            sqlConnection.Close();

        }
    }
}
