﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6_Basic_Command
{
    public partial class BillForm : Form
    {
        public BillForm()
        {
            InitializeComponent();
			LoadBills();
        }
		public void LoadBills()
		{
			string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
			// Tạo đối tượng kết nối
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			// Tạo đối tượng thực thi lệnh
			SqlCommand sqlCommand = sqlConnection.CreateCommand();

			sqlCommand.CommandText = "SELECT * FROM Bills where checkoutdate = 1/11/2021";

			sqlConnection.Open();

			string categoryName = sqlCommand.ExecuteScalar().ToString();
			this.Text = "Danh sách toàn bộ hóa đơn";

			SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);

			DataTable table = new DataTable("Food");
			adapter.Fill(table);

			dgvHoaDon.DataSource = table;

			// Prevent user to edit ID
			dgvHoaDon.Columns[0].ReadOnly = true;

			sqlConnection.Close();
		}


		private void BillForm_Load(object sender, EventArgs e)
        {

        }

        private void dgvHoaDon_DoubleClick(object sender, EventArgs e)
        {
			BillDetailsForm billDetails = new BillDetailsForm();
			string billID = dgvHoaDon.SelectedRows[0].Cells[0].Value.ToString();
			billDetails.LoadBillDetails(int.Parse(billID));
			billDetails.Show();
		}

        private void dgvHoaDon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
