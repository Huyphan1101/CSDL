﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataAccess;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
   public  class FoodBl
    {
        FoodDA foodAD = new FoodDA();
        public List<FoodRecord> GetAll()
        {
            return foodAD.GetAll();
        }
        public FoodRecord GetByID (int ID)
        {
            // Lấy hết 
            List<FoodRecord> list = GetAll();
            // Duyệt để tim
            foreach (var item in list )
            {
                if (item.ID == ID)
                    return item;

            }
            return null;
        }
        public List <FoodRecord> Find (string key)
        {
            List<FoodRecord> list = GetAll(); // Lấy hết
            List<FoodRecord> result = new List<FoodRecord>();
            foreach (var item in list)
            {
                if (item.ID.ToString().Contains(key)
                    || item.Name.Contains(key)
                    || item.Unit.Contains(key)
                    || item.Price.ToString().Contains(key)
                    || item.Notes.Contains(key))
                    result.Add(item);
            }
            return result;
        }
        public int Insert(FoodRecord food)
        {
            return foodAD.Insert_Update_Delete(food, 0);
        }
        public int Update(FoodRecord food)
        {
            return foodAD.Insert_Update_Delete(food, 1);

        }
        public int Delete (FoodRecord food)
        {
            return foodAD.Insert_Update_Delete(food, 2);
        }

    }
}
