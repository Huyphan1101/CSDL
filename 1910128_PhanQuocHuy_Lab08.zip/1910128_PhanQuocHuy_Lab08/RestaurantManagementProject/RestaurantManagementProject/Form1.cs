﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using DataAccess;
using BusinessLogic;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Category> listCategory = new List<Category>();
        List<FoodRecord> listFood = new List<FoodRecord>();
        FoodRecord foodCurrent = new FoodRecord();

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtUnit.Text = "";
            txtPrice.Text = "";
            txtNotes.Text = "";
            if (cbbCategory.Items.Count > 0)
                cbbCategory.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadCategory();
            LoadFoodDataToListView();
        }

        private void LoadFoodDataToListView()
        {
            FoodBl foodBL = new FoodBl();
            listFood = foodBL.GetAll();
            int count = 1;
            lvFood.Items.Clear();
            foreach (var food in listFood)
            {
                // Số thứ tự
                ListViewItem item = lvFood.Items.Add(count.ToString());
                item.SubItems.Add(food.Name);
                item.SubItems.Add(food.Unit);
                item.SubItems.Add(food.Price.ToString());
               
                string foodName = listCategory.Find(x =>x.ID == food.FoodCategoryID).Name;
                item.SubItems.Add(foodName);
               
                item.SubItems.Add(food.Notes);
                count++;
            }
        }

        private void LoadCategory()
        {
            CategoryBL categoryBL = new CategoryBL();
            listCategory = categoryBL.GetAll();
            cbbCategory.DataSource = listCategory;
            cbbCategory.ValueMember = "ID";
            cbbCategory.DisplayMember = "Name";

        }

        private void lvFood_Click(object sender, EventArgs e)
        {
            // Duyệt toàn bộ dữ liệu trong ListView
            for (int i = 0; i < lvFood.Items.Count; i++)
            {
              
                if (lvFood.Items[i].Selected)
                {
                    foodCurrent = listFood[i];
                    txtName.Text = foodCurrent.Name;
                    txtUnit.Text = foodCurrent.Unit;
                    txtPrice.Text = foodCurrent.Price.ToString();
                    txtNotes.Text = foodCurrent.Notes;
                    
                    cbbCategory.SelectedIndex = listCategory
                   .FindIndex(x => x.ID == foodCurrent.FoodCategoryID);
                }

            }

        }
        public int InsertFood()
        {
            FoodRecord food = new FoodRecord();
            food.ID = 0;
            if (txtName.Text == "" || txtUnit.Text == "" || txtPrice.Text == "")
                MessageBox.Show("Chưa nhập dữ liệu cho các ô, vui lòng nhập lại");
            else
            {
                
                food.Name = txtName.Text;
                food.Unit = txtUnit.Text;
                food.Notes = txtNotes.Text;
                
                int price = 0;
                try
                {
                 
                    price = int.Parse(txtPrice.Text);
                }
                catch
                {
                    // Nếu sai, gán giá = 0
                    price = 0;
                }
                food.Price = price;
                
                food.FoodCategoryID = int.Parse(cbbCategory.SelectedValue.ToString());
                
                FoodBl foodBL = new FoodBl();
                
                return foodBL.Insert(food);
            }
            return -1;

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int result = InsertFood();
            if (result > 0) 
            {
              
                MessageBox.Show("Thêm dữ liệu thành công");
                
                LoadFoodDataToListView();
            }
            
            else MessageBox.Show("Thêm dữ liệu không thành công. Vui lòng kiểm tra lại dữ liệu nhập");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn xoá mẫu tin này?", "Thông báo",
 MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
               
                FoodBl foodBL = new FoodBl();
                if (foodBL.Delete(foodCurrent) > 0)
                {
                    MessageBox.Show("Xoá thực phẩm thành công");
                    // Tải tữ liệu lên ListView
                    LoadFoodDataToListView();
                }
                else MessageBox.Show("Xoá không thành công");
            }
        }
        public int UpdateFood()
        {
            
            FoodRecord food = foodCurrent;
            
            if (txtName.Text == "" || txtUnit.Text == "" || txtPrice.Text == "")
                MessageBox.Show("Chưa nhập dữ liệu cho các ô, vui lòng nhập lại");
            else
            {
               
                food.Name = txtName.Text;
                food.Unit = txtUnit.Text;
                food.Notes = txtNotes.Text;
                int price = 0;
                try
                {
                   
                    price = int.Parse(txtPrice.Text);
                }
                catch
                {
                    // Nếu sai, gán giá = 0
                    price = 0;
                }
                food.Price = price;
              
                food.FoodCategoryID = int.Parse(cbbCategory.SelectedValue.ToString());
               
                FoodBl foodBL = new FoodBl();
                
                return foodBL.Update(food);
            }
            return -1;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int result = UpdateFood();
            if (result > 0) 
            {
         
                MessageBox.Show("Cập nhật dữ liệu thành công");
               
                LoadFoodDataToListView();
            }
            
            else MessageBox.Show("Cập nhật dữ liệu không thành công. Vui lòng kiểm tra lại dữ liệu nhập");

        }
    }
}
