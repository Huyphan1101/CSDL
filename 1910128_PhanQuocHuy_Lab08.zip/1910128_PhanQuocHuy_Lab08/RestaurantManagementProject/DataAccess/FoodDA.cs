﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace DataAccess
{
    public class FoodDA
    {
        public List<FoodRecord> GetAll ()
        {
            SqlConnection Conn = new SqlConnection(Ultilities.ConnectionString);
            Conn.Open();
            SqlCommand sql = Conn.CreateCommand();
            sql.CommandType = CommandType.StoredProcedure;
            sql.CommandText = Ultilities.Food_GetAll;
            SqlDataReader reader = sql.ExecuteReader();
            List<FoodRecord> list = new List<FoodRecord>();
            while (reader.Read())
            {
                FoodRecord food = new FoodRecord();
                food.ID = Convert.ToInt32(reader["ID"]);
                food.Name = reader["Name"].ToString();
                food.Unit = reader["Unit"].ToString();
                food.FoodCategoryID = Convert.ToInt32(reader["FoodCategoryID"]);
                food.Price = Convert.ToInt32(reader["Price"]);
                food.Notes = reader["Notes"].ToString();
                list.Add(food);


            }
            Conn.Close();
            return list;
        }
        public int Insert_Update_Delete(FoodRecord food , int action)
        {
            SqlConnection Conn = new SqlConnection(Ultilities.ConnectionString);
            Conn.Open();
            SqlCommand sql = Conn.CreateCommand();
            sql.CommandType = CommandType.StoredProcedure;
            sql.CommandText = Ultilities.Food_InsertUpdateDelete;
            SqlParameter IDPara = new SqlParameter("@ID", SqlDbType.Int);
            IDPara.Direction = ParameterDirection.InputOutput;
            sql.Parameters.Add(IDPara).Value = food.ID;
            //Các biến còn lại chỉ truyền vào 
            sql.Parameters.Add("@Name", SqlDbType.NVarChar, 200).Value = food.Name;
            sql.Parameters.Add("@Unit", SqlDbType.NVarChar, 200).Value = food.Unit;
            sql.Parameters.Add("@FoodCategoryID", SqlDbType.Int).Value = food.FoodCategoryID;
            sql.Parameters.Add("@Price", SqlDbType.Int).Value = food.Price;
            sql.Parameters.Add("@Notes", SqlDbType.NVarChar, 200).Value = food.Notes;
            sql.Parameters.Add("@Action", SqlDbType.Int).Value = action;
            int result = sql.ExecuteNonQuery();
            if (result > 0)
                // Nếu thành công thì trả về ID đã thêm vào
                return (int)sql.Parameters["ID"].Value;
            return 0;



        }
    }
}
