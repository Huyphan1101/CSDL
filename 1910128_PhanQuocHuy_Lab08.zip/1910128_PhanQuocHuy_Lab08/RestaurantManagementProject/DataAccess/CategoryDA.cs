﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Data;

namespace DataAccess
{
   public class CategoryDA
    {
        public List <Category> GetAll()
        {
            SqlConnection Conn = new SqlConnection(Ultilities.ConnectionString);
            Conn.Open();
            SqlCommand sql = Conn.CreateCommand();
            sql.CommandType = CommandType.StoredProcedure;
            sql.CommandText = Ultilities.Category_GetAll;
            SqlDataReader reader = sql.ExecuteReader();
            List<Category> list = new List<Category>();
            while (reader.Read())
            {
                Category category = new Category();
                category.ID = Convert.ToInt32(reader["ID"]);
                category.Name = reader["Name"].ToString();
                category.Type = Convert.ToInt32(reader["Type"]);
                list.Add(category);
            }
            Conn.Close();
            return list;
            
        }
        public int Insert_Update_Delete (Category category, int action)
        {
            SqlConnection Conn = new SqlConnection(Ultilities.ConnectionString);
            Conn.Open();
            SqlCommand sql = Conn.CreateCommand();
            sql.CommandType = CommandType.StoredProcedure;
            sql.CommandText = Ultilities.Category_InsertUpdateDelete;
            SqlParameter IDPara = new SqlParameter("@ID", SqlDbType.Int);
            IDPara.Direction = ParameterDirection.InputOutput; // vừa vào vừa ra
            sql.Parameters.Add("@Name", SqlDbType.NVarChar, 200).Value = category.Name;
            sql.Parameters.Add("@Type", SqlDbType.Int).Value = category.Type;
            sql.Parameters.Add("@Action", SqlDbType.Int).Value = action;
            int result = sql.ExecuteNonQuery();
            if (result > 0) // Nếu Add thành công thì trả về ID đã thêm
                return (int)sql.Parameters["ID"].Value;
            return 0;

        }
    }
}
