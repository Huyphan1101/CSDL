﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           
            InitializeComponent();
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            text1.ForeColor = Color.Fuchsia;
            

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn có chắc muốn thoát không ?", "Error", MessageBoxButtons.YesNoCancel);
            Application.Exit();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
           this.ReSet();
        }

        private void ReSet()
        {
            this.cboMaHV.Text = "";
            this.txtHoTen.Text = "";
            this.dtpNgayDangKi.Value = DateTime.Now;
            this.rdNam.Checked = true;
            this.ckTiengAnhA.Checked = false;
            this.ckTiengAnhB.Checked = false;
            this.ckTinHocA.Checked = false;
            this.ckTinHocB.Checked = false;
            this.txtTongTien.Text = "";
        }

        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            int s = 0;
            if (ckTinHocA.Checked)
                s += int.Parse(lblTienTHA.Text.Split('.')[0]);
            if (ckTinHocB.Checked)
                s += int.Parse(lblTienTHB.Text.Split('.')[0]);
            if (ckTiengAnhA.Checked)
                s += int.Parse(lblTienTAA.Text.Split('.')[0]);
            if (ckTiengAnhB.Checked)
                s += int.Parse(lblTienTAB.Text.Split('.')[0]);
            this.txtTongTien.Text = s + ".000 đồng";

        }

        private void txtTongTien_TextChanged(object sender, EventArgs e)
        {

        }
    }
 }
    
    

