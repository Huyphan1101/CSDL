﻿namespace MyForm2
{
    internal class DanhSachGiaoVien
    {
        public DanhSachGiaoVien()
        {
        }
    }
}