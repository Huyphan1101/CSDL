﻿namespace MyForm2
{
    internal class dsGiaoVien
    {
    }
}