﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyForm2
{
    public enum KieuTim
    {
        TheoMa,
        TheoHoTen,
        TheoSoDienThoai
    }
}
