﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyForm2
{
    public partial class FormTimKiem : Form
    {
        private QuanLyGiaoVien quanlyGV;

      
        
        

        public FormTimKiem(object quanlyGV)
        {
            InitializeComponent();
        }
        public FormTimKiem(QuanLyGiaoVien qlgv) : this()
        {
            quanlyGV = qlgv;
        }

        public FormTimKiem()
        {
        }

        private void FormTimKiem_Load(object sender, EventArgs e)
        {
            
        }
        private void rdMaGV_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbMaSoGV.Checked)
            {
                lblTim.Text = rdbMaSoGV.Text;
                txtSearch.Text = "";
            }
        }

        private void rdHoTen_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbHoTen.Checked)
            {
                lblTim.Text = rdbHoTen.Text;
                txtSearch.Text = "";
            }
        }

        private void rdSoDT_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbSDT.Checked)
            {
                lblTim.Text = rdbSDT.Text;
                txtSearch.Text = "";
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            
        }

        private static void NewMethod(object ketQua, frmTBGiaoVien frm)
        {
            frm.SetText(ketQua.ToString());
        }


        private void btnOk_Click_1(object sender, EventArgs e)
        {

            var kieuTim = KieuTim.TheoHoTen;
            if (rdbMaSoGV.Checked)
            {
                kieuTim = KieuTim.TheoMa;
            }
            else if (rdbHoTen.Checked)
            {
                kieuTim = KieuTim.TheoHoTen;
            }
            else if (rdbSDT.Checked)
            {
                kieuTim = KieuTim.TheoSoDienThoai;
            }

            var ketQua = quanlyGV.Tim(txtSearch.Text, kieuTim);

            if (ketQua is null)
            {
                MessageBox.Show("Không tìm thấy thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                frmTBGiaoVien frm = new frmTBGiaoVien();
                NewMethod(ketQua, frm);
                frm.ShowDialog();
            }

        }

        private void lblTim_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

    