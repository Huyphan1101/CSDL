﻿using System;

namespace MyForm2
{
    internal class frmTBGiaoVien
    {
        internal void SetText(string v)
        {
            throw new NotImplementedException();
        }

        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}