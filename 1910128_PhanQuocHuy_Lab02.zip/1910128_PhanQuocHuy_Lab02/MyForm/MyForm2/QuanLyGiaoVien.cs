﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace MyForm2
{
    public class QuanLyGiaoVien : GiaoVien
    {

        internal object Tim(string text, object kieuTim)
        {
            throw new NotImplementedException();
        }
        QuanLyGiaoVien quanlyGV = new QuanLyGiaoVien();
        public QuanLyGiaoVien (string maso, string hoten)
        {

        }

        public QuanLyGiaoVien()
        {
            DanhSachGiaoVien dsGiaoVien = new DanhSachGiaoVien();


        }

        public void Them(GiaoVien gv)
        {

            this.Them(gv);
        }
        public void Tim(GiaoVien gv)
        {
            this.Tim(gv);
        }
    }
   
    
   

}
