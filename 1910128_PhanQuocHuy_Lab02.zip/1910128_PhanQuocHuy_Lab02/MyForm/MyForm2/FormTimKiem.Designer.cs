﻿
namespace MyForm2
{
    partial class FormTimKiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdbMaSoGV = new System.Windows.Forms.RadioButton();
            this.rdbHoTen = new System.Windows.Forms.RadioButton();
            this.rdbSDT = new System.Windows.Forms.RadioButton();
            this.btnOk = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblTim = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rdbMaSoGV
            // 
            this.rdbMaSoGV.AutoSize = true;
            this.rdbMaSoGV.Location = new System.Drawing.Point(183, 83);
            this.rdbMaSoGV.Name = "rdbMaSoGV";
            this.rdbMaSoGV.Size = new System.Drawing.Size(74, 24);
            this.rdbMaSoGV.TabIndex = 4;
            this.rdbMaSoGV.TabStop = true;
            this.rdbMaSoGV.Text = "Mã GV";
            this.rdbMaSoGV.UseVisualStyleBackColor = true;
            // 
            // rdbHoTen
            // 
            this.rdbHoTen.AutoSize = true;
            this.rdbHoTen.Location = new System.Drawing.Point(317, 83);
            this.rdbHoTen.Name = "rdbHoTen";
            this.rdbHoTen.Size = new System.Drawing.Size(77, 24);
            this.rdbHoTen.TabIndex = 5;
            this.rdbHoTen.TabStop = true;
            this.rdbHoTen.Text = "Họ Tên";
            this.rdbHoTen.UseVisualStyleBackColor = true;
            // 
            // rdbSDT
            // 
            this.rdbSDT.AutoSize = true;
            this.rdbSDT.Location = new System.Drawing.Point(472, 83);
            this.rdbSDT.Name = "rdbSDT";
            this.rdbSDT.Size = new System.Drawing.Size(123, 24);
            this.rdbSDT.TabIndex = 6;
            this.rdbSDT.TabStop = true;
            this.rdbSDT.Text = "Số Điện Thoại";
            this.rdbSDT.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(491, 142);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(94, 29);
            this.btnOk.TabIndex = 7;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click_1);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(237, 142);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(216, 27);
            this.txtSearch.TabIndex = 8;
            // 
            // lblTim
            // 
            this.lblTim.AutoSize = true;
            this.lblTim.Location = new System.Drawing.Point(101, 146);
            this.lblTim.Name = "lblTim";
            this.lblTim.Size = new System.Drawing.Size(53, 20);
            this.lblTim.TabIndex = 9;
            this.lblTim.Text = "Mã GV";
            // 
            // FormTimKiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 183);
            this.Controls.Add(this.lblTim);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.rdbSDT);
            this.Controls.Add(this.rdbHoTen);
            this.Controls.Add(this.rdbMaSoGV);
            this.Name = "FormTimKiem";
            this.Text = "FormTimKiem";
            this.Load += new System.EventHandler(this.FormTimKiem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdbMaSoGV;
        private System.Windows.Forms.RadioButton rdbHoTen;
        private System.Windows.Forms.RadioButton rdbSDT;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblTim;
    }
}