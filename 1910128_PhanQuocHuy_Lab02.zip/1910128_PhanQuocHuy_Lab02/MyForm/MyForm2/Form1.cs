﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyForm2
{
    public partial class Form1 : Form
    {
        private List<GiaoVien> ds;
        
        private object quanLyGV;

        public string MaSo { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ds = new List<GiaoVien>();
            text1.ForeColor = Color.Magenta;
            string lienhe = "http://it.dlu.edu.vn/e-learning/Default.aspx";
            this.lbLienHe.Links.Add(0, lienhe.Length, lienhe);
            this.cboMaSo.SelectedItem = this.cboMaSo.Items[0];
        }
       

        private void btnChon_Click(object sender, EventArgs e)
        {
            int i = this.lbDanhSachMonHoc.SelectedItems.Count - 1;
            while (i >= 0)
            {
                this.lbMonHocGiaoVienDay.Items.Add(lbDanhSachMonHoc.SelectedItems[i]);
                this.lbDanhSachMonHoc.Items.Remove(lbDanhSachMonHoc.SelectedItems[i]);
                i--;

            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int i = this.lbMonHocGiaoVienDay.SelectedItems.Count - 1;
            while (i >= 0)
            {
                this.lbDanhSachMonHoc.Items.Add(lbMonHocGiaoVienDay.SelectedItems[i]);
                this.lbMonHocGiaoVienDay.Items.Remove(lbMonHocGiaoVienDay.SelectedItems[i]);
                i--;
            }


        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ReSet();
        }

        private void ReSet()
        {
            this.cboMaSo.Text = "";
            this.txtHoTen.Text = "";
            this.tbGmail.Text = "";
            this.mtbSDT.Text = "";
            this.rbNam.Checked = true;
            for (int i = 0; i < clbNgoaiNgu.Items.Count - 1; i++)
                clbNgoaiNgu.SetItemChecked(i, false);
            foreach (object ob in this.lbMonHocGiaoVienDay.Items)
                this.lbDanhSachMonHoc.Items.Add(ob);
            this.lbMonHocGiaoVienDay.Items.Clear();

        }

        private void lbLienHe_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string s = e.Link.LinkData.ToString();
            Process.Start(s);

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            Thông_tin_giáo_viên_nhập frm = new Thông_tin_giáo_viên_nhập();
            frm.SetText(GetGiaoVien().ToString());
            frm.ShowDialog();
        }

        private object GetGiaoVien()
        {
            string gt = "Nam";
            if (rbNu.Checked) gt = "Nữ";
            GiaoVien gv = new GiaoVien();
            gv.MaSo = this.cboMaSo.Text;
            gv.GioiTinh = gt;
            gv.HoTen = this.txtHoTen.Text;
            gv.NgaySinh = this.dtpNgaySinh.Value;
            gv.Mail = this.tbGmail.Text;
            gv.SoDT = mtbSDT.Text;
            string ngoaingu = "";
            for (int i = 0; i < clbNgoaiNgu.Items.Count - 1; i++)
                if (clbNgoaiNgu.GetItemChecked(i))
                    ngoaingu += clbNgoaiNgu.Items[i] + ";";
            gv.NgoaiNgu = ngoaingu.Split(';');
            DanhMucMonHoc mh = new DanhMucMonHoc();
            foreach (object ob in lbMonHocGiaoVienDay.Items)
                mh.Them(new MonHoc(ob.ToString()));
            gv.dsMonHoc = mh;
            return gv;

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            
                MessageBox.Show("Giáo viên có mã số " + this.MaSo + " đã tồn tại", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
                MessageBox.Show("Thêm giáo viên thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    

        private void btnExit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn có chắc muốn thoát không?",
                "Error", MessageBoxButtons.YesNoCancel);
            Application.Exit();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            var frmTimKiem = new FormTimKiem(quanLyGV);
            frmTimKiem.ShowDialog();
        }
    }
    }

