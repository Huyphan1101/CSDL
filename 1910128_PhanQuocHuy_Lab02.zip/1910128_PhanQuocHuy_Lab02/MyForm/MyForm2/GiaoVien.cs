﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace MyForm2
{
    public class GiaoVien
    {
        public string MaSo { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh;
        public DanhMucMonHoc dsMonHoc;
        public string GioiTinh;
        public string[] NgoaiNgu;
        public string SoDT;
        public string Mail;
        private string text1;
        private TextBox txtHoTen;
        private DateTime value;
        private bool @checked;
        private string text2;
        private string text3;

        public GiaoVien(string text)
        {
            dsMonHoc = new DanhMucMonHoc();
            NgoaiNgu = new string[10];

        }
        public GiaoVien(string maso, string hoten, DateTime ngaysinh, DanhMucMonHoc ds , string gt , string []nn,string sdt, string mail)
        {
            this.MaSo = maso;
            this.HoTen = hoten;
            this.NgaySinh = ngaysinh;
            this.dsMonHoc = ds;
            this.GioiTinh = gt;
            this.NgoaiNgu = nn;
            this.SoDT = sdt;
            this.Mail = mail;
        }

        public GiaoVien(string text1, TextBox txtHoTen, DateTime value, bool @checked, string text2, string text3)
        {
            this.text1 = text1;
            this.txtHoTen = txtHoTen;
            this.value = value;
            this.@checked = @checked;
            this.text2 = text2;
            this.text3 = text3;
        }

        public GiaoVien()
        {
        }

        public override string ToString()
        {
            string s = "Mã số:" + MaSo + "\n" + "Họ Tên :" + HoTen + "\n" + "Ngày sinh:" + NgaySinh.ToString() + "\n" + "Giới tinh :" + GioiTinh + "\n" + "Số DT:" + SoDT + "\n" + "Mail" + Mail + "\n";
            string sngoaingu = "Ngoại Ngữ :";
            foreach (string t in NgoaiNgu)
                sngoaingu += t + ";";
            string Monday = "Danh sách môn dạy :";
            foreach (MonHoc mh in dsMonHoc.ds)
                Monday += mh + ";";
            s += "\n" + sngoaingu + "\n" + Monday;
            return s;
        }
    }
}
