﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyForm2
{
    public partial class FormTBGiaoVien : Form
    {
        public FormTBGiaoVien()
        {
            InitializeComponent();
        }

        internal void SetText(object p)
        {
            throw new NotImplementedException();
        }
    }
}
