﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyForm2
{
    public partial class Thông_tin_giáo_viên_nhập : Form
    {
        public Thông_tin_giáo_viên_nhập()
        {
            InitializeComponent();
        }
        public void SetText(string s) 
        {
            this.lblThongBao.Text = s;
        }
        private void Thông_tin_giáo_viên_nhập_Load(object sender, EventArgs e)
        {

        }
    }
}
