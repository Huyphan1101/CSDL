﻿
namespace lab07
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbbCategory = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvFoodList = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmCalculateQuantityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmSeperatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmAddFoodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmUpdateFoodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblQuantity1 = new System.Windows.Forms.Label();
            this.lblCatName1 = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblCatName = new System.Windows.Forms.Label();
            this.txtSearchByName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tsmAccountFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFoodList)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbbCategory
            // 
            this.cbbCategory.FormattingEnabled = true;
            this.cbbCategory.Location = new System.Drawing.Point(190, 33);
            this.cbbCategory.Name = "cbbCategory";
            this.cbbCategory.Size = new System.Drawing.Size(162, 24);
            this.cbbCategory.TabIndex = 0;
            this.cbbCategory.SelectedIndexChanged += new System.EventHandler(this.cbbCategory_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Chọn món ăn";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dgvFoodList
            // 
            this.dgvFoodList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvFoodList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFoodList.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvFoodList.Location = new System.Drawing.Point(12, 74);
            this.dgvFoodList.MultiSelect = false;
            this.dgvFoodList.Name = "dgvFoodList";
            this.dgvFoodList.RowHeadersWidth = 51;
            this.dgvFoodList.RowTemplate.Height = 24;
            this.dgvFoodList.Size = new System.Drawing.Size(889, 344);
            this.dgvFoodList.TabIndex = 2;
            this.dgvFoodList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dgvFoodList.DoubleClick += new System.EventHandler(this.dgvFoodList_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmCalculateQuantityToolStripMenuItem,
            this.tsmSeperatorToolStripMenuItem,
            this.tsmAddFoodToolStripMenuItem,
            this.tsmUpdateFoodToolStripMenuItem,
            this.tsmAccountFormToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(219, 152);
            // 
            // tsmCalculateQuantityToolStripMenuItem
            // 
            this.tsmCalculateQuantityToolStripMenuItem.Name = "tsmCalculateQuantityToolStripMenuItem";
            this.tsmCalculateQuantityToolStripMenuItem.Size = new System.Drawing.Size(218, 24);
            this.tsmCalculateQuantityToolStripMenuItem.Text = "Tính số lượng đã bán";
            this.tsmCalculateQuantityToolStripMenuItem.Click += new System.EventHandler(this.label1_Click);
            // 
            // tsmSeperatorToolStripMenuItem
            // 
            this.tsmSeperatorToolStripMenuItem.Name = "tsmSeperatorToolStripMenuItem";
            this.tsmSeperatorToolStripMenuItem.Size = new System.Drawing.Size(218, 24);
            this.tsmSeperatorToolStripMenuItem.Text = "tsmSeperator";
            // 
            // tsmAddFoodToolStripMenuItem
            // 
            this.tsmAddFoodToolStripMenuItem.Name = "tsmAddFoodToolStripMenuItem";
            this.tsmAddFoodToolStripMenuItem.Size = new System.Drawing.Size(218, 24);
            this.tsmAddFoodToolStripMenuItem.Text = "tsmAddFood";
            this.tsmAddFoodToolStripMenuItem.Click += new System.EventHandler(this.tsmAddFoodToolStripMenuItem_Click);
            // 
            // tsmUpdateFoodToolStripMenuItem
            // 
            this.tsmUpdateFoodToolStripMenuItem.Name = "tsmUpdateFoodToolStripMenuItem";
            this.tsmUpdateFoodToolStripMenuItem.Size = new System.Drawing.Size(218, 24);
            this.tsmUpdateFoodToolStripMenuItem.Text = "tsmUpdateFood";
            this.tsmUpdateFoodToolStripMenuItem.Click += new System.EventHandler(this.tsmUpdateFoodToolStripMenuItem_Click);
            // 
            // lblQuantity1
            // 
            this.lblQuantity1.AutoSize = true;
            this.lblQuantity1.Location = new System.Drawing.Point(69, 454);
            this.lblQuantity1.Name = "lblQuantity1";
            this.lblQuantity1.Size = new System.Drawing.Size(64, 17);
            this.lblQuantity1.TabIndex = 3;
            this.lblQuantity1.Text = "Có tất cả";
            this.lblQuantity1.Click += new System.EventHandler(this.lblQuantity1_Click);
            // 
            // lblCatName1
            // 
            this.lblCatName1.AutoSize = true;
            this.lblCatName1.Location = new System.Drawing.Point(285, 454);
            this.lblCatName1.Name = "lblCatName1";
            this.lblCatName1.Size = new System.Drawing.Size(147, 17);
            this.lblCatName1.TabIndex = 4;
            this.lblCatName1.Text = "Nhóm ăn thuộc nhóm ";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(155, 454);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(20, 17);
            this.lblQuantity.TabIndex = 5;
            this.lblQuantity.Text = "...";
            // 
            // lblCatName
            // 
            this.lblCatName.AutoSize = true;
            this.lblCatName.Location = new System.Drawing.Point(450, 454);
            this.lblCatName.Name = "lblCatName";
            this.lblCatName.Size = new System.Drawing.Size(20, 17);
            this.lblCatName.TabIndex = 6;
            this.lblCatName.Text = "...";
            this.lblCatName.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtSearchByName
            // 
            this.txtSearchByName.Location = new System.Drawing.Point(622, 35);
            this.txtSearchByName.Name = "txtSearchByName";
            this.txtSearchByName.Size = new System.Drawing.Size(235, 22);
            this.txtSearchByName.TabIndex = 7;
            this.txtSearchByName.TextChanged += new System.EventHandler(this.txtSearchByName_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(480, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Tìm kiếm theo tên";
            // 
            // tsmAccountFormToolStripMenuItem
            // 
            this.tsmAccountFormToolStripMenuItem.Name = "tsmAccountFormToolStripMenuItem";
            this.tsmAccountFormToolStripMenuItem.Size = new System.Drawing.Size(218, 24);
            this.tsmAccountFormToolStripMenuItem.Text = "tsmAccountForm";
            this.tsmAccountFormToolStripMenuItem.Click += new System.EventHandler(this.tsmAccountFormToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 495);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSearchByName);
            this.Controls.Add(this.lblCatName);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblCatName1);
            this.Controls.Add(this.lblQuantity1);
            this.Controls.Add(this.dgvFoodList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbbCategory);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFoodList)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbbCategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvFoodList;
        private System.Windows.Forms.Label lblQuantity1;
        private System.Windows.Forms.Label lblCatName1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmCalculateQuantityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmSeperatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmAddFoodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmUpdateFoodToolStripMenuItem;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblCatName;
        private System.Windows.Forms.TextBox txtSearchByName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem tsmAccountFormToolStripMenuItem;
    }
}

