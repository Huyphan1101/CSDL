﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab07
{
    public partial class AddNew : Form
    {
        public AddNew()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "Insert into Category (Name , [Type])" + " Values (N' " + txtAddNew.Text + "' ," + txtType.Text + ")";
          
            conn.Open();
            int numRowAffected = cmd.ExecuteNonQuery();
            conn.Close();
            if (numRowAffected == 1)
            {
             
                MessageBox.Show("Thêm nhóm món ăn thành công ");

                txtAddNew.Text = "";
                txtType.Text = "";
               
            }


            else
            {
                MessageBox.Show("Đã có lỗi xảy ra , vui lòng thử lại ");
            }
        }
    }
}
