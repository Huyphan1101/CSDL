﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab07
{
    public partial class OrdersForm : Form
    {
        public OrdersForm()
        {
            InitializeComponent();
			LoadBills();
        }

        private void OrdersForm_Load(object sender, EventArgs e)
        {

        }
		public void LoadBills()
		{
			string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
			// Tạo đối tượng kết nối
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			// Tạo đối tượng thực thi lệnh
			SqlCommand sqlCommand = sqlConnection.CreateCommand();

			sqlCommand.CommandText = "SELECT * FROM BillDetails ";

			sqlConnection.Open();

			string categoryName = sqlCommand.ExecuteScalar().ToString();
			this.Text = "Danh sách toàn bộ hóa đơn" + categoryName;

			SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);

			DataTable table = new DataTable("BillDetails");
			adapter.Fill(table);

			dgvHoaDon.DataSource = table;

			// Prevent user to edit ID
			dgvHoaDon.Columns[0].ReadOnly = true;

			sqlConnection.Close();
		}

        internal void LoadBillDetails(int v)
        {
            throw new NotImplementedException();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
			string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
			// Tạo đối tượng kết nối
			SqlConnection sqlConnection = new SqlConnection(connectionString);
			// Tạo đối tượng thực thi lệnh
			SqlCommand sqlCommand = sqlConnection.CreateCommand();
			sqlCommand.CommandText = "Select Sum (Total price) from BillDetails Where Total price > 10000";
			sqlConnection.Open();
			txtSum.Text = "";
			sqlConnection.Close();

		}
    }
}
