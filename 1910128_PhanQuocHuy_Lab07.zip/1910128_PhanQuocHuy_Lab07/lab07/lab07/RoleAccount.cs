﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab07
{
    public partial class RoleAccount : Form
    {
        SqlConnection conn;
        SqlCommand command;
        string str = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loaddata()
        {
            command = conn.CreateCommand();
            command.CommandText = " Select * from RoleAccount ";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dgvRoleAccount.DataSource = table;
        }
        public RoleAccount()
        {
            InitializeComponent();
        }

        private void RoleAccount_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(str);
            conn.Open();
            loaddata();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            command = conn.CreateCommand();

            command.CommandText = "insert into RoleAccount values ('" + txtID.Text + "','" + txtAccount.Text + "','" + txtActived.Text + "','" + txtNotes.Text + "' )";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void dgvRoleAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.ReadOnly = true;
            int i;
            i = dgvRoleAccount.CurrentRow.Index;
            txtID.Text = dgvRoleAccount.Rows[i].Cells[0].Value.ToString();
            txtAccount.Text = dgvRoleAccount.Rows[i].Cells[1].Value.ToString();
            txtActived.Text = dgvRoleAccount.Rows[i].Cells[2].Value.ToString();
            txtNotes.Text = dgvRoleAccount.Rows[i].Cells[3].Value.ToString();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            command = conn.CreateCommand();
            command.CommandText = "Update RoleAccount set AccountName = '" + txtAccount.Text + "', Actived = '" + txtActived.Text + "' , Notes= '" + txtNotes.Text + "' Where RoleID= '"+txtID.Text+"'";
            command.ExecuteNonQuery();
            loaddata();
        }
    }
}
