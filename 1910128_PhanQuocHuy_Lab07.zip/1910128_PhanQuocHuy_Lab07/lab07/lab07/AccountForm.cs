﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab07
{
	public partial class AccountForm : Form

	{
		SqlConnection conn;
		SqlCommand command;
		string str = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
		SqlDataAdapter adapter = new SqlDataAdapter();
		DataTable table = new DataTable();
		void loaddata()
		{
			command = conn.CreateCommand();
			command.CommandText = " Select * from Account ";
			adapter.SelectCommand = command;
			table.Clear();
			adapter.Fill(table);
			dgvAccount.DataSource = table;
		}

		public AccountForm()
		{
			InitializeComponent();

		}

		private void AccountForm_Load(object sender, EventArgs e)
		{
			conn = new SqlConnection(str);
			conn.Open();
			loaddata();

		}






		private void btnAdd_Click(object sender, EventArgs e)
		{
			command = conn.CreateCommand();
			command.CommandText = "insert into Account values ('" + txtAccName.Text + "','" + txtPass.Text + "','" + txtEmail.Text + "','" + txtFullName.Text + "','" + txtTell.Text + "','" + dataDatatime.Text + "' )";
			command.ExecuteNonQuery();
			loaddata();


		}

		private void btnUpdate_Click(object sender, EventArgs e)
		{

			string connectionString = @"server=LAPTOP-IU2D0JB7\HUYSQLSERVER; database = RestaurantManagement; Integrated Security = True ";
			SqlConnection conn = new SqlConnection(connectionString);
			SqlCommand cmd = conn.CreateCommand();
			cmd.CommandText = " execute updateAccount @AccountName , @Password, @Email, @FullName , @Tell, @Datetime ";
			cmd.Parameters.Add("@AccountName ", SqlDbType.NVarChar, 100);
			cmd.Parameters.Add("@Password  ", SqlDbType.NVarChar, 200);
			cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 10000);
			cmd.Parameters.Add("@FullName", SqlDbType.NVarChar, 1000);
			cmd.Parameters.Add("@Tell", SqlDbType.NVarChar, 200);
			cmd.Parameters.Add("2Datetime", SqlDbType.DateTime);
			cmd.Parameters["@AccountName "].Value = txtAccName.Text;
			cmd.Parameters["@Password"].Value = txtPass.Text;
			cmd.Parameters["@Email"].Value = txtEmail.Text;
			cmd.Parameters["@FullName"].Value = txtFullName.Text;
			cmd.Parameters["@Tell"].Value = txtTell.Text;
			cmd.Parameters["@Datetime"].Value = dataDatatime.Value;
			conn.Open();
			int numRowAffected = cmd.ExecuteNonQuery();
			if (numRowAffected > 0)
			{
				string name = cmd.Parameters["@AccountName "].Value.ToString();
				MessageBox.Show("Cập nhật tài khoản thành công " + name);
				this.ResetText();

			}
			conn.Close();
			conn.Dispose();
			loaddata();
		

}
		
        private void dgvAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
			int i;
			i = dgvAccount.CurrentRow.Index;
			txtAccName.Text = dgvAccount.Rows[i].Cells[0].Value.ToString();
			txtPass.Text = dgvAccount.Rows[i].Cells[1].Value.ToString();
			txtEmail.Text = dgvAccount.Rows[i].Cells[2].Value.ToString();
			txtFullName.Text = dgvAccount.Rows[i].Cells[3].Value.ToString();
			txtTell.Text = dgvAccount.Rows[i].Cells[4].Value.ToString();
			dataDatatime.Text = dgvAccount.Rows[i].Cells[5].Value.ToString();
		}

        private void xemNhậtKíHoạtĐộngToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void txtFullName_TextChanged(object sender, EventArgs e)
        {

        }

        private void xemDanhSáchCácVaiTròToolStripMenuItem_Click(object sender, EventArgs e)
        {
			RoleAccount frm = new RoleAccount();
				frm.Show();
			
		}
    }
}
